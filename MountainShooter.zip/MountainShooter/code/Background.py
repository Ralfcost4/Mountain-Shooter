#!/usr/bin/python
# -*- coding: utf-8 -*-
from code.Const import WIN_WIDTH, ENTITY_SPEED
from code.Entity import Entity


class Background(Entity):
    def __init__(self, name: str, position: tuple, is_parallax: bool = False):
        super().__init__(name, position)
        self.is_parallax = is_parallax
        self.parallax_factor = 1.0

    def move(self):
        if self.is_parallax:
            base_speed = ENTITY_SPEED[self.name]
            
            if 'Bg0' in self.name or 'Bg1' in self.name:
                self.parallax_factor = 0.5
            elif 'Bg2' in self.name:
                self.parallax_factor = 0.7
            elif 'Bg3' in self.name:
                self.parallax_factor = 1.3
            elif 'Bg4' in self.name:
                self.parallax_factor = 1.5
            
            scroll_speed = base_speed * self.parallax_factor
            self.rect.centerx -= scroll_speed
        else:
            self.rect.centerx -= ENTITY_SPEED[self.name]
        
        if self.rect.right <= 0:
            self.rect.left = WIN_WIDTH